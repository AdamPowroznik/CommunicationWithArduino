Toggle Switch Control Library
=====================
Use the Toggle Switch Control Library to create highly customizable toggle switch controls in WPF and Silverlight apps.

Available as a Nuget package: http://nuget.org/List/Packages/ToggleSwitch

[![View Demo][2]][1]

  [1]: http://yetilabs.org/toggleswitch
  [2]: http://i3.codeplex.com/Download?ProjectName=ToggleSwitch&DownloadId=282953 (View Demo)

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/ejensen/toggle-switch-control/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

_Mirror of http://toggleswitch.codeplex.com_
