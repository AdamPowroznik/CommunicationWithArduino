using System.Windows.Controls;

namespace Demo
{
	public partial class Styling : UserControl
	{
		public Styling()
		{
			InitializeComponent();
		}
	}
}